<p>Name: <?php echo e($user_name); ?></p>
<p>E-mail: <?php echo e($user_email); ?></p>
<p>Message: <?php echo e($user_message); ?></p>