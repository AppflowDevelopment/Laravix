<?php $__env->startSection('content'); ?>

<h1><?php echo e($page->title); ?></h1>
<div><?php echo e($page->content); ?></div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>