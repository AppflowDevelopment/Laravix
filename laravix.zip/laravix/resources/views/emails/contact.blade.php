<p>Name: {{ $user_name }}</p>
<p>E-mail: {{ $user_email }}</p>
<p>Message: {{ $user_message }}</p>