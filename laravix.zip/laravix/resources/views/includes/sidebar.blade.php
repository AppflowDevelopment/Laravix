<div class="sidebar-module">
	<h4>Links:</h4>
    <p>Company profiles:</p>
	<ul>
		<li><a href="https://appflow.eu/" target="_blank">AppFlow</a></li>
		<li><a href="http://rifix.net/" target="_blank">Rifix</a></li>
		<li><a href="http://blog.rifix.net/" target="_blank">Blog</a></li>
		<li><a href="http://vsichkifirmi.com/" target="_blank">VsichkiFirmi</a></li>
		<li><a href="http://vix.bg/" target="_blank">Vix Media</a></li>
	</ul>
</div>

<div class="sidebar-module">
	<h4>Social Media</h4>
    <ul>
		<li><a href="https://www.facebook.com/appflow.eu" target="_blank">Facebook</a></li>
		<li><a href="https://plus.google.com/+AppflowEu" target="_blank">Google+</a></li>
		<li><a href="https://www.youtube.com/channel/UCFRz2CxQKNDthODWpFtvBww" target="_blank">Youtube</a></li>
		<li><a href="https://twitter.com/_appflow" target="_blank">Twitter</a></li>
		<li><a href="https://appflow.eu/blog/feed/" target="_blank">RSS</a></li>
	</ul>
</div>